package com.example.taxapp;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
//import com.basgeekball.awesomevalidation.AwesomeValidation;
//import com.basgeekball.awesomevalidation.ValidationStyle;
//import com.google.common.collect.Range;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    //private AwesomeValidation awesomeValidation;

    private TextView tax;
    private EditText incomeInput;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Tax Calculator for 1040");
        setContentView(R.layout.activity_screen2);
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        readTaxData();
        Button exit = findViewById(R.id.exitBtn);
        RadioButton single = findViewById(R.id.singleCheckBox);
        RadioButton married = findViewById(R.id.MarriedCheckBox);
        RadioButton separate = findViewById(R.id.separateCheckBox);
        RadioButton household = findViewById(R.id.headCheckBox);
        Button clear = findViewById(R.id.clearBtn);
        tax = findViewById(R.id.Tax);
        //displays tax rates for those filing as single
        single.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tax.setText("Estimated Tax =$"+singleRate(handleSingle(single)).toString());
            }
        });
//displays tax rates values for people filing as jointly married.
        married.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tax.setText("Estimated Tax =$"+String.valueOf(marriedRate(handleJointly(married))));
            }
        });
//displays tax rates values for people filing as separately married.
        separate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tax.setText("Estimated Tax =$"+String.valueOf(separateRate(handleSeparately(separate))));
            }
        });
//displays tax rates values for people filing as head of household.
        household.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tax.setText("Estimated Tax =$"+String.valueOf(headRate(handleHead(household))));
                System.out.println(String.valueOf(headRate(handleHead(household))));
            }
        });
        //exit
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radioGroup.clearCheck();
                tax.setText("");
            }

        });
    }

    //Creates a list of values that are stored as TaxData
    private List<TaxData> TaxData = new ArrayList<>();
    private void readTaxData() {
        //reads files
        InputStream input = getResources().openRawResource(R.raw.table2);
        BufferedReader reader = new BufferedReader (
            (new InputStreamReader(input, Charset.forName("UTF-8")))
        );
        String line = "";
        try{
            while ((line = reader.readLine())!=null){
                //splits values when there's a space
                String [] tokens = line.split(" ");
                TaxData data = new TaxData();
                //assigns data to objects
                data.setMinIncome(Double.parseDouble(tokens[0]));
                data.setMaxIncome(Double.parseDouble(tokens[1]));
                data.setFilingSingly(Double.parseDouble(tokens[2]));
                data.setFilingJointly(Double.parseDouble(tokens[3]));
                data.setFilingSeparately(Double.parseDouble(tokens[4]));
                data.setHeadOfHouseHold(Double.parseDouble(tokens[5]));
                TaxData.add(data);
                //Log.d("MainActivity2","Line: "+data);
            }
        } catch (IOException e) {
            Log.wtf("MainActivity2","Error reading line"+line,e);
            e.printStackTrace();
        }

    }

    //calculates tax rate for people filing as singles
    public Double singleRate (double annualIncome) {
        double finalAmount =0;
        if(annualIncome<0){
            return 0.0;
        }
        if(annualIncome < 100000&& annualIncome>=0) {
            //For incomes less than 100000
            for (int i = 0; i < TaxData.size(); i++) {
                if (annualIncome >= TaxData.get(i).getMinIncome() && annualIncome < TaxData.get(i).getMaxIncome()) {
                    finalAmount = TaxData.get(i).getFilingSingly();
                }
            }
        }

        else if (annualIncome >=100000 && annualIncome<=163300){
            finalAmount = (annualIncome*0.24)- 5920.50;
        }
        else if (annualIncome >=163300 && annualIncome<=207350){
            finalAmount = (annualIncome*0.32) -  18984.50;
        }
        else if (annualIncome>=207350 && annualIncome<=518400){
            finalAmount = (annualIncome*0.35)- 25205.00;
        }
        else if (annualIncome>518400){
            finalAmount = (annualIncome* 0.37) - 35573.00;
        }
        return finalAmount;
    }
    //tax rate for people filing as married
    public Double marriedRate (double annualIncome){
        double finalAmountMarried = 0;
        if(annualIncome<0){
            return 0.0;
        }
        if(annualIncome < 100000 && annualIncome>=0) {
            //For incomes less than 100000
            for (int i = 0; i < TaxData.size(); i++) {
                if (annualIncome >= TaxData.get(i).getMinIncome() && annualIncome < TaxData.get(i).getMaxIncome()) {
                    finalAmountMarried = TaxData.get(i).getFilingJointly();
                }
            }
        }
        else if (100000<annualIncome && annualIncome<=171050){
            finalAmountMarried = (annualIncome*0.22)- 8420.00;
        }
        else if (171050<=annualIncome && annualIncome<=326600){
            finalAmountMarried = (annualIncome*0.24) -  11841.00;
        }
        else if (326600<=annualIncome && annualIncome<=414700){
            finalAmountMarried = (annualIncome*0.32)- 37969.00;
        }
        else if (414700<=annualIncome && annualIncome<=622050){
            finalAmountMarried = (annualIncome*0.35) - 50410;
        }
        else if (annualIncome>622050){
            finalAmountMarried = (annualIncome* 0.37) - 62851;
        }
        return finalAmountMarried;
    }
    //tax rate for people filing as married separately
    public double separateRate (double annualIncome){
        double finalAmountSeparate = 0;
        if (annualIncome<0){
            return 0.0;
        }
        if(annualIncome < 100000 && annualIncome>=0) {
            //For incomes less than 100000
            for (int i = 0; i < TaxData.size(); i++) {
                if (annualIncome >= TaxData.get(i).getMinIncome() && annualIncome < TaxData.get(i).getMaxIncome()) {
                    finalAmountSeparate = TaxData.get(i).getFilingSeparately();
                }
            }
        }
        else if (100000<annualIncome && annualIncome<=163300){
            finalAmountSeparate = (annualIncome*0.24)- 5920.50;
        }
        else if (163300<=annualIncome && annualIncome<=207350){
            finalAmountSeparate = (annualIncome*0.32) -  18984.50;
        }
        else if (207350<=annualIncome && annualIncome<=518400){
            finalAmountSeparate = (annualIncome*0.35)- 25205.00;
        }
        else if (annualIncome>518400){
            finalAmountSeparate = (annualIncome* 0.37) - 35573.00;
        }
        return finalAmountSeparate;
    }
    //tax rate for people filing as head of household
    public double headRate (double annualIncome){
        double finalAmountHead = 0;
        if(annualIncome<0){
            return 0.0;
        }
        if(annualIncome < 100000 && annualIncome>=0) {
            //For incomes less than 100000
            for (int i = 0; i < TaxData.size(); i++) {
                if (annualIncome >= TaxData.get(i).getMinIncome() && annualIncome < TaxData.get(i).getMaxIncome()) {
                    finalAmountHead = TaxData.get(i).getHeadOfHouseHold();
                }
            }
        }
        else if (100000<annualIncome && annualIncome<=163300){
            finalAmountHead = (annualIncome*0.24)- 7362;
        }
        else if (163300<=annualIncome && annualIncome<=207350){
            finalAmountHead = (annualIncome*0.32) -  20426;
        }
        else if (207350<=annualIncome && annualIncome<=518400){
            finalAmountHead = (annualIncome*0.35)- 26646.50;
        }
        else if (annualIncome>518400){
            finalAmountHead = (annualIncome* 0.37) - 37014.50;
        }
        return finalAmountHead;
    }

    public double handleSingle (View v){
        TextView income = findViewById(R.id.incomeInput);
        double annual = Double.parseDouble(income.getText().toString());
        return annual-12400;
    }
    public double handleJointly (View v){
        TextView income = findViewById(R.id.incomeInput);
        double annual = Double.parseDouble(income.getText().toString());
        return annual-24800;
    }
    public double handleSeparately (View v){
        TextView income = findViewById(R.id.incomeInput);
        double annual = Double.parseDouble(income.getText().toString());
        return annual-12400;
    }
    public double handleHead (View v){
        TextView income = findViewById(R.id.incomeInput);
        double annual = Double.parseDouble(income.getText().toString());
        return annual-18650;
    }
}

