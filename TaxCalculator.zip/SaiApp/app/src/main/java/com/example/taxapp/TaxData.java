package com.example.taxapp;

public class TaxData {
    private double minIncome;
    private double maxIncome;
    private double filingSingly;
    private double filingJointly;
    private double filingSeparately;
    private double headOfHouseHold;

    public double getMinIncome() {
        return minIncome;
    }

    public void setMinIncome(double minIncome) {
        this.minIncome = minIncome;
    }

    public double getMaxIncome() {
        return maxIncome;
    }

    public void setMaxIncome(double maxIncome) {
        this.maxIncome = maxIncome;
    }

    public double getFilingSingly() {
        return filingSingly;
    }

    public void setFilingSingly(double filingSingly) {
        this.filingSingly = filingSingly;
    }

    public double getFilingJointly() {
        return filingJointly;
    }

    public void setFilingJointly(double filingJointly) {
        this.filingJointly = filingJointly;
    }

    public double getFilingSeparately() {
        return filingSeparately;
    }

    public void setFilingSeparately(double filingSeparately) {
        this.filingSeparately = filingSeparately;
    }

    public double getHeadOfHouseHold() {
        return headOfHouseHold;
    }

    public void setHeadOfHouseHold(double headOfHouseHold) {
        this.headOfHouseHold = headOfHouseHold;
    }

    @Override
    public String toString() {
        return "TaxData{" +
                "minIncome=" + minIncome +
                ", maxIncome=" + maxIncome +
                ", filingSingly=" + filingSingly +
                ", filingJointly=" + filingJointly +
                ", filingSeparately=" + filingSeparately +
                ", headOfHouseHold=" + headOfHouseHold +
                '}';
    }
}
